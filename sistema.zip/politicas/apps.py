from django.apps import AppConfig


class PoliticasConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'politicas'
