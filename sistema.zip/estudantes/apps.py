from django.apps import AppConfig


class EstudantesConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'estudantes'
