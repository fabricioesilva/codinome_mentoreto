import os

# # SECURITY WARNING: don't run with debug turned on in production!
# DEBUG = False

# ALLOWED_HOSTS = [
#     'sistema.expertzone.com.br',
#     'www.sistema.expertzone.com.br',
#     'www.expertzone.com.br'
# ]
# CSRF_TRUSTED_ORIGINS = [
#     "http://sistema.expertzone.com.br",
#     "https://sistema.expertzone.com.br",
# ]


# SITE_CONTACT_FONE = ''
# CONTACTUS_EMAIL = 'contato@expertzone.com.br'
# NOREPLY_EMAIL = 'noreply@expertzone.com.br'

# DOMAIN = 'sistema.expertzone.com.br'
# LOCALHOST_URL = 'https://sistema.expertzone.com.br/'
# PROTOCOLO = 'https'

# SITE_NAME = 'Expert Zone'
# SITE_SLOGAN = 'Conectando mentores e estudantes.'


# EMAIL_BACKEND = 'django.core.mail.backends.smtp.EmailBackend'
# EMAIL_HOST = 'mail.expertzone.com.br'
# EMAIL_HOST_USER = 'noreply@expertzone.com.br'
# EMAIL_HOST_PASSWORD = str(os.getenv('USER_PASS_KEY'))
# EMAIL_PORT = 587
# EMAIL_USE_TLS = True


# #         'ENGINE': 'django.db.backends.postgresql',
