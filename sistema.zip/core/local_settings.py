import os

# SECURITY WARNING: don't run with debug turned on in production!
DEBUG = False

DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.postgresql',
        'NAME': 'expertzo_db1',
        'HOST': 'localhost',
        'PORT': '5432',
        'USER': 'expertzo_root',
        'PASSWORD': 'etEn2@dmSU#$8',
    }
}

ALLOWED_HOSTS = [
    'sistema.expertzone.com.br',
    'www.sistema.expertzone.com.br',
    'www.expertzone.com.br'
]
CSRF_TRUSTED_ORIGINS = [
    "http://sistema.expertzone.com.br",
    "https://sistema.expertzone.com.br",
]

LOCALHOST_URL = 'https://www.expertzone.com.br/'
EMAIL_BACKEND = 'django.core.mail.backends.smtp.EmailBackend'
EMAIL_HOST = 'mail.expertzone.com.br'
EMAIL_HOST_USER = 'noreply@expertzone.com.br'
EMAIL_HOST_PASSWORD = str(os.getenv('USER_PASS_KEY'))
EMAIL_PORT = 587
EMAIL_USE_TLS = True


# #         'ENGINE': 'django.db.backends.postgresql',
